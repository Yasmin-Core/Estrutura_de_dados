#include <stdio.h>
#include <stdlib.h>
#include "minhalib(TAD1).h"

void calculoVantagens(float nHoras, float salHora, int nFilhos,
    float valFilho, float *salBruto, float *salFamilia,
    float *vantagens);
void calculoDeducoes(float taxIR, float salBruto, float *INSS,
    float *IRPF, float *deducoes);

int main(){
    float numHoras, salHora, valFilho, taxIR;
    int numFilhos;
    //antes eram variáveis globais:
    float salBruto, salFamilia, vantagens, INSS, IRPF, deducoes;

    printf("\t\tPrograma calculo de Vantagens e Deducoes.\n\n");
    printf("Digite o numero de horas trabalhadas: ");
    scanf(" %f", &numHoras);
    printf("\nDigite o valor do salario hora: ");
    scanf(" %f", &salHora);
    printf("\nInforme quantos filhos o funcionario tem: ");
    scanf(" %d", &numFilhos);
    printf("\nDigite o valor do salario familia por filho: ");
    scanf(" %f", &valFilho);
    printf("\nInforme a taxa de desconto do IR:");
    scanf(" %f", &taxIR);
    taxIR = taxIR / 100;

    calculoVantagens(numHoras, salHora, numFilhos, valFilho,
    &salBruto, &salFamilia, &vantagens);
    calculoDeducoes(taxIR, salBruto, &INSS, &IRPF, &deducoes);

    system("cls");
    printf("\t\tRelatorio do calculo de Vantagens e Deducoes.\n\n");
    printf("O salario bruto do funcionario e: %.2f\n", salBruto);
    printf("O salario familia do funcionario e: %.2f\n", salFamilia);
    printf("As Vantagens do funcionario sao: %.2f\n", vantagens);
    printf("\n\nE descontado R$ %.2f, referente ao INSS.\n", INSS);
    printf("Desconto de R$ %.2f, refente ao imposto de renda.\n", IRPF);
    printf("O total de deducoes do funcionario e: %.2f\n", deducoes);
}
