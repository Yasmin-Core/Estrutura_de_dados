// as funcoes do arquivo "atividade(TAD)1.c"

int main();

void calculoVantagens(float nHoras, float salHora, int nFilhos,
                    float valFilho, float *salBruto, float *salFamilia,
                    float *vantagens);

void calculoDeducoes(float taxIR, float salBruto, float *INSS,
float *IRPF, float *deducoes);