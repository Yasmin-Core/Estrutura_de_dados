#include <stdio.h>
#include <stdlib.h>
#include "minhalib(TAD1).h"

void calculoVantagens(float nHoras, float salHora, int nFilhos,
                    float valFilho, float *salBruto, float *salFamilia,
                    float *vantagens){

    *salBruto = nHoras * salHora;
    *salFamilia = nFilhos * valFilho;
    *vantagens = *salBruto * *salFamilia;
}

void calculoDeducoes(float taxIR, float salBruto, float *INSS,
float *IRPF, float *deducoes){

    *INSS = salBruto * 0.08;
    *IRPF = salBruto * taxIR;
    *deducoes = *INSS + *IRPF;
}